
<?php $__env->startSection('content'); ?>
    <header class="mb-3">
        <a href="#" class="burger-btn d-block d-xl-none">
            <i class="bi bi-justify fs-3"></i>
        </a>
    </header>

    <div class="page-heading">
        <div class="page-title">
            <div class="row">
                <div class="col-12 col-md-6 order-md-1 order-last">
                    <h3>System Users</h3>
                    <p class="text-subtitle text-muted">For Edit New User Fill This Form</p>
                </div>
                <?php if($message = Session::get('success')): ?>
                    <div class="alert alert-success">
                        <p><?php echo e($message); ?></p>
                    </div>
                <?php endif; ?>
                <div class="col-12 col-md-6 order-md-2 order-first">
                    <nav aria-label="breadcrumb" class="breadcrumb-header float-start float-lg-end">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="/">Jobs</a></li>
                            <li class="breadcrumb-item" aria-current="page"><a href="<?php echo e(route('users.index')); ?>">Users</a>
                            </li>
                            <li class="breadcrumb-item active" aria-current="page">Edit</li>

                        </ol>
                    </nav>
                </div>
            </div>
        </div>
        <section class="section">
            <div class="row match-height">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h4 class="card-title">Edit User</h4>
                        </div>
                        <div class="card-content">
                            <div class="card-body">
                                <form class="form" action="<?php echo e(route('users.update', $Users->id)); ?>" method="POST"
                                    enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PUT'); ?>
                                    <?php if($request->session()->get('IsAdmin')): ?>
                                        <div class="row">
                                            <div class="col-md-6 col-12">
                                                <div class="form-group">
                                                    <label for="FullName">Full Name</label>
                                                    <input type="text" id="FullName" class="form-control"
                                                        placeholder="Full Name" name="FullName"
                                                        value="<?php echo e($Users->FullName); ?>">
                                                    <?php $__errorArgs = ['FullName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <p><small class="text-muted"><code><?php echo e($message); ?></code></small>
                                                        </p>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>

                                            <div class="col-md-6 col-12">
                                                <div class="form-group">
                                                    <label for="ProfilePhoto">Profile Photo</label>
                                                    <input type="file" id="ProfilePhoto" class="form-control"
                                                        name="ProfilePhoto">
                                                    <?php $__errorArgs = ['ProfilePhoto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <p><small class="text-muted"><code><?php echo e($message); ?></code></small>
                                                        </p>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                            <div class="col-md-6 col-12">
                                                <div class="form-group">
                                                    <label for="PhoneNumber">Phone Number</label>
                                                    <input type="tel" id="PhoneNumber" class="form-control"
                                                        placeholder="Phone Number" name="PhoneNumber"
                                                        value="<?php echo e($Users->PhoneNumber); ?>">
                                                    <?php $__errorArgs = ['PhoneNumber'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <p><small class="text-muted"><code><?php echo e($message); ?></code></small>
                                                        </p>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                            <div class="col-md-6 col-12">
                                                <div class="form-group">
                                                    <label for="Email">Email</label>
                                                    <input type="email" id="Email" class="form-control" name="Email"
                                                        placeholder="Email" value="<?php echo e($Users->Email); ?>">
                                                    <?php $__errorArgs = ['Email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <p><small class="text-muted"><code><?php echo e($message); ?></code></small>
                                                        </p>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                            <div class="col-md-6 col-12">
                                                <div class="form-group">
                                                    <label for="Password">Password</label>
                                                    <input type="Password" id="Password" class="form-control"
                                                        name="Password" placeholder="Password"
                                                        value="<?php echo e($Users->Password); ?>">
                                                    <?php $__errorArgs = ['Password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <p><small class="text-muted"><code><?php echo e($message); ?></code></small>
                                                        </p>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                            <div class="form-group col-12">
                                                <div class='form-check'>
                                                    <div class="checkbox">
                                                        <?php if($Users->IsAdmin == 1): ?>
                                                            <input type="checkbox" id="IsAdmin" name="IsAdmin"
                                                                class='form-check-input' checked>
                                                        <?php else: ?>
                                                            <input type="checkbox" id="IsAdmin" name="IsAdmin"
                                                                class='form-check-input'>
                                                        <?php endif; ?>
                                                        
                                                        <label for="checkbox5">Is Admin</label>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-12 d-flex justify-content-end">
                                                <button type="submit" class="btn btn-primary me-1 mb-1">Submit</button>
                                                <button type="reset"
                                                    class="btn btn-light-secondary me-1 mb-1">Reset</button>
                                            </div>
                                        </div>
                                    <?php else: ?>
                                        <div class="row">
                                            <div class="col-md-6 col-12">
                                                <div class="form-group">
                                                    <label for="ProfilePhoto">Profile Photo</label>
                                                    <input type="file" id="ProfilePhoto" class="form-control"
                                                        name="ProfilePhoto">
                                                    <?php $__errorArgs = ['ProfilePhoto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <p><small class="text-muted"><code><?php echo e($message); ?></code></small>
                                                        </p>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                            <div class="col-md-6 col-12">
                                                <div class="form-group">
                                                    <label for="Email">Email</label>
                                                    <input type="email" id="Email" class="form-control"
                                                        name="Email" placeholder="Email" value="<?php echo e($Users->Email); ?>">
                                                    <?php $__errorArgs = ['Email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <p><small class="text-muted"><code><?php echo e($message); ?></code></small>
                                                        </p>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                            <div class="col-md-6 col-12">
                                                <div class="form-group">
                                                    <label for="Password">Password</label>
                                                    <input type="Password" id="Password" class="form-control"
                                                        name="Password" placeholder="Password"
                                                        value="<?php echo e($Users->Password); ?>">
                                                    <?php $__errorArgs = ['Password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <p><small class="text-muted"><code><?php echo e($message); ?></code></small>
                                                        </p>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                            <div class="col-12 d-flex justify-content-end">
                                                <button type="submit" class="btn btn-primary me-1 mb-1">Submit</button>
                                                <button type="reset"
                                                    class="btn btn-light-secondary me-1 mb-1">Reset</button>
                                            </div>
                                        </div>
                                    <?php endif; ?>

                                </form>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\All Projects\New folder\userprofile-project\resources\views/users/edit.blade.php ENDPATH**/ ?>