
<?php $__env->startSection('content'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendors/simple-datatables/style.css')); ?>">

    <header class="mb-3">
        <a href="#" class="burger-btn d-block d-xl-none">
            <i class="bi bi-justify fs-3"></i>
        </a>
    </header>

    <div class="page-heading">
        <div class="page-title">
            <div class="row">
                <div class="col-12 col-md-6 order-md-1 order-last">
                    <h3>System Users</h3>
                    <p class="text-subtitle text-muted">For user to check they list</p>
                </div>
                <?php if($message = Session::get('success')): ?>
                    <div class="alert alert-success">
                        <p><?php echo e($message); ?></p>
                    </div>
                <?php endif; ?>
                <div class="col-12 col-md-6 order-md-2 order-first">
                    <nav aria-label="breadcrumb" class="breadcrumb-header float-start float-lg-end">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="/">Jobs</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Users</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
        <section class="section">
            <div class="card">
                <div class="card-header">
                    <a class="btn btn-success" href="<?php echo e(route('users.create')); ?>"> Create User</a>
                </div>
                <div class="card-body">
                    <table class="table table-striped" id="table1">
                        <thead>
                            <tr>
                                <th> Full Name </th>
                                <th> Phone Number </th>
                                <th> Email </th>
                                
                                <th> Role </th>
                                <th> Link </th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $User): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <div class="d-flex align-items-center">
                                            <div class="avatar avatar-md">
                                                <?php if($User->ProfilePhoto != null && $User->ProfilePhoto != ''): ?>
                                                    <img src="data:image/png;base64,<?php echo e($User->ProfilePhoto); ?>">

                                                    <?php if($User->id % 3 == 0): ?>
                                                        <span class="avatar-status bg-success"></span>
                                                    <?php else: ?>
                                                        <span class="avatar-status bg-danger"></span>
                                                    <?php endif; ?>
                                                <?php else: ?>
                                                  <img src="https://bootdey.com/img/Content/avatar/avatar7.png">
                                                <?php endif; ?>
                                            </div>
                                            <p class="font-bold ms-3 mb-0"><a href="#"><?php echo e($User->FullName); ?></a></p>
                                        </div>
                                    </td>

                                    <td><?php echo e($User->PhoneNumber); ?></td>
                                    <td><?php echo e($User->Email); ?></td>
                                    
                                    <td>
                                        <?php if($User->IsAdmin == 1): ?>
                                            <span class="badge bg-dark">Admin</span>
                                        <?php else: ?>
                                            <span class="badge bg-primary">User</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e(substr($User->Link, strpos($User->Link, 'text='))); ?></td>
                                    <td>
                                        <form action="<?php echo e(route('users.destroy', $User->id)); ?>" method="Post">
                                            <a class="btn btn-primary" href="<?php echo e(route('users.edit', $User->id)); ?>">Edit</a>
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-danger">Delete</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>

                </div>
            </div>

        </section>
    </div>
    <script src="<?php echo e(asset('assets/vendors/simple-datatables/simple-datatables.js')); ?>"></script>
    <script>
        // Simple Datatable
        let table1 = document.querySelector('#table1');
        let dataTable = new simpleDatatables.DataTable(table1);
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\All Projects\New folder\userprofile-project\resources\views/users/index.blade.php ENDPATH**/ ?>